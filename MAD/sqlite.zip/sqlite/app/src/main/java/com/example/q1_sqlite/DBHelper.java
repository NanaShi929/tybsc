package com.example.q1_sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(@Nullable Context context)
    {

        super(context, "Students.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
       db.execSQL("create Table StudentDetails(rollNo TEXT primary key , name TEXT,phoneno TEXT ,marks TEXT )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
       db.execSQL("drop Table if exists StudentDetails ");
    }
public Boolean insert(String rollno,String name,String phoneno, String marks){
        SQLiteDatabase db=this.getWritableDatabase();
    ContentValues contentValues=new ContentValues();
    contentValues.put("rollno",rollno);
    contentValues.put("name",name);
    contentValues.put("phoneno",phoneno);
    contentValues.put("marks",marks);
    long result = db.insert("StudentDetails",null,contentValues);
    if (result == -1){
        return false;
    }
    else {
        return true;
    }
    }
    public  Boolean delete(String rollno){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from StudentDetails where rollno=?",new String[]{rollno});
        if(cursor.getCount()>0)
        {
            long result = db.delete("StudentDetails","rollno=?",new String[]{rollno});
            if (result == -1){
                return  false;
            }
            else {
                return  true;
            }
        }
        else {
            return  false;
        }
    }
    public Cursor view(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from StudentDetails",null);
        return cursor;
    }

}
