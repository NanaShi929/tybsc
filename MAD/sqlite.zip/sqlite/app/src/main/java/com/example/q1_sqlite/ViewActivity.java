package com.example.q1_sqlite;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ViewActivity extends AppCompatActivity
{
//    TextView details;
    ListView listview;
    private ArrayList<String> listitem;
    Button back;

    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        back=findViewById(R.id.back);
        listview=findViewById(R.id.listview);
        String data=getIntent().getStringExtra("data");
        listitem=new ArrayList<>();
        final ArrayAdapter<String> listadapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,listitem);
        listview.setAdapter(listadapter);
        listitem.add(data);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String value=listitem.get(position);
                Toast.makeText(ViewActivity.this, value, Toast.LENGTH_LONG).show();
            }
        });


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(ViewActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
