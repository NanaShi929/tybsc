package com.example.q1_sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
EditText rollno,name,phoneno,marks;
Button insert,delete,view;
DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rollno=findViewById(R.id.rollno);
        name=findViewById(R.id.name);
        phoneno=findViewById(R.id.phoneno);
        marks=findViewById(R.id.marks);
        insert=findViewById(R.id.insert);
        delete=findViewById(R.id.delete);
        view=findViewById(R.id.view);
        dbHelper=new DBHelper(this);
        insert.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String rollnoTXT=rollno.getText().toString();
                String nameTXT=name.getText().toString();
                String phonenoTXT=phoneno.getText().toString();
                String marksTXT=marks.getText().toString();
                Boolean checkinsert=dbHelper.insert(rollnoTXT,nameTXT,phonenoTXT,marksTXT);
                if (checkinsert == true)
                {
                   Toast.makeText(MainActivity.this,"Data Inserted", Toast.LENGTH_LONG).show();


                }
                else
                {
                   Toast.makeText(MainActivity.this,"Data Not Inserted", Toast.LENGTH_LONG).show();
                }
                rollno.setText("");
                name.setText("");
                phoneno.setText("");
                marks.setText("");
            }


        });
        delete.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String rollnoTXT=rollno.getText().toString();
                Boolean checkdelete=dbHelper.delete(rollnoTXT);
                if (checkdelete == true)
                {
                    Toast.makeText(MainActivity.this,"Data Deleted", Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Data Not Deleted", Toast.LENGTH_LONG).show();
                }
                rollno.setText("");
                name.setText("");
                phoneno.setText("");
                marks.setText("");
            }
        });
        view.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Cursor res=dbHelper.view();
                if(res.getCount()==0){
                    Toast.makeText(MainActivity.this,"Data Doesn't Exists", Toast.LENGTH_LONG).show();
                    return;
                }
                StringBuilder data=new StringBuilder();
                while (res.moveToNext())
                {
                  data.append("Roll_No     :- ").append(res.getString(0)).append("\n");
                  data.append("Name        :- ").append(res.getString(1)).append("\n");
                  data.append("Phone_No :- ").append(res.getString(2)).append("\n");
                  data.append("Marks       :- ").append(res.getString(3)).append("\n\n\n\n");

                }
                Intent intent=new Intent(MainActivity.this, ViewActivity.class);
                intent.putExtra("data", data.toString());
                startActivity(intent);
            }
        });

    }
}